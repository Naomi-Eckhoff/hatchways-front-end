# hatchways-front-end

I felt like I could use the practice on doing this with just js instead of React. As it turns out I did need that practice.

I decided not to use local storage as I was assuming this front end would be hooked into a back end for long term storage of tags.
